

<?php $__env->startSection('title', 'عرض الوصفات'); ?>
<?php $__env->startSection('page-title', 'عرض الوصفات'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        /* .add-section { ... } -- هذا الجزء يمكن إزالته إذا لم تعد هناك دالة إضافة */
        .form-control,
        .form-select {
            border-radius: 8px;
            border: 1px solid #ddd;
            padding: 10px 15px;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }

        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
            background-color: white;
            /* إضافة خلفية للجدول */
        }

        .action-buttons .btn {
            padding: 5px 10px;
            font-size: 12px;
            margin: 0 2px;
        }

        .flag-img {
            width: 55px;
            height: auto;
            border-radius: 3px;
            box-shadow: 0 0 3px rgba(0, 0, 0, 0.2);
        }

        .table th,
        .table td {
            vertical-align: middle;
            /* محاذاة عمودية للمحتوى في الجدول */
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-hover table-striped"> 
            <thead class="bg-primary text-white"> 
                <tr>
                    <th>#</th>
                    <th>اللغة</th>
                    <th>الوصفة</th>
                    <th>الحالة</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td>
                            <div class="flex gap-1">
                                
                               <?php if($language->dish_image): ?>
                                <img src="<?php echo e(Storage::url($language->dish_image)); ?>" alt="<?php echo e($language->title); ?>"
                                    class="flag-img ">
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/default-recipe-image.png')); ?>" alt="بدون صورة"
                                    class="flag-img ">
                            <?php endif; ?>
                                <?php echo e($language->name); ?>

                            </div>
                        </td>
                        <td>
                            <div class="flex gap-1">
                                <div class="flex gap-1">
                                    <?php if($language->dish_image): ?>
                                <img src="<?php echo e(Storage::url($language->dish_image)); ?>" alt="<?php echo e($language->title); ?>"
                                    class="flag-img">
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/default-recipe-image.png')); ?>" alt="بدون صورة"
                                    class="flag-img">
                            <?php endif; ?>
                                    53135
                                </div>
                                - كشري
                            </div>


                        </td>

                        <td>
                            <span class="badge <?php echo e($language->status_badge_class); ?>">
                                <?php echo e($language->status_text); ?>

                            </span>
                        </td>
                        <td>
                            <div class="action-buttons">
                                
                                
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4"> 
                            <i class="fas fa-language text-muted" style="font-size: 3rem;"></i>
                            <p class="text-muted mt-2">لا توجد بيانات لغات</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    

    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    
    

    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\food-project\resources\views/admin/recipeView/index.blade.php ENDPATH**/ ?>