

<?php $__env->startSection('title', 'تفاصيل الوصفة: ' . $recipe->title); ?>
<?php $__env->startSection('page-title', 'تفاصيل الوصفة'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .details-card {
            background: white;
            color: black;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            position: relative;
        }

        .details-card h4 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(255, 255, 255, 0.3);
            padding-bottom: 10px;
        }

        .details-item {
            margin-bottom: 15px;
            font-size: 1.1rem;
            display: flex;
            /* justify-content: space-between; */
            flex-direction: row;
        }

        .details-item strong {
            margin-bottom: 5px;
            color: rgba(0, 0, 0, 0.8);
            font-weight: bold;
        }

        .details-image {
            width: 100%;
            height: 36%;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        .status-badge {
            padding: 0.6em 1em;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: bold;
        }

        .status-active {
            background-color: #28a745;
            color: white;
        }

        .status-inactive {
            background-color: #dc3545;
            color: white;
        }

        .status-free {
            background-color: #17a2b8;
            color: white;
        }

        .status-paid {
            background-color: #ffc107;
            color: #333;
        }

        .btn-back {
            background-color: white;
            color: #764ba2;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .btn-back:hover {
            background-color: #eee;
            color: #667eea;
        }

        .section-title {
            font-size: 1.3rem;
            margin-top: 25px;
            margin-bottom: 10px;
            color: rgba(0, 0, 0, 0.9);
            border-bottom: 1px solid rgba(255, 255, 255, 0.5);
            padding-bottom: 5px;
        }

        .content-list {
            list-style: none;
            padding-left: 0;
        }

        .content-list li {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 8px 15px;
            border-radius: 5px;
            margin-bottom: 8px;
            display: flex;
            align-items: flex-start;
        }

        .content-list li i {
            margin-right: 10px;
            color: #a7d9ff;
            font-size: 1.2rem;
            margin-top: 3px;
        }

        .tags-container .badge {
            background-color: rgba(255, 255, 255, 0.2);
            color: black;
            margin-right: 5px;
            margin-bottom: 5px;
            padding: 0.6em 1em;
            border-radius: 5px;
            font-weight: normal;
        }

        .media-preview {
            max-width: 150px;
            max-height: 100px;
            object-fit: contain;
            border-radius: 5px;
            margin-left: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .media-preview.video {
            max-height: 120px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="details-card">
        <h4 class="text-center"><?php echo e($recipe->title); ?></h4>

        <div class="row">
            <div class="col-md-5 text-center">
                <?php if($recipe->dish_image): ?>
                    <img src="<?php echo e(Storage::url($recipe->dish_image)); ?>" alt="<?php echo e($recipe->title); ?>" class="details-image">
                <?php else: ?>
                    <img src="<?php echo e(asset('assets/default-recipe-image.png')); ?>" alt="بدون صورة" class="details-image">
                <?php endif; ?>
            </div>
            <div class="col-md-7">
                <div class="flex">
<div class="details-item ml-2">
    <strong>صورة الطاهي:</strong>
    <?php if($recipe->chef && $recipe->chef->chefProfile && $recipe->chef->chefProfile->official_image): ?>
        <img src="<?php echo e(Storage::url($recipe->chef->chefProfile->official_image)); ?>" alt="Official Image"
            class="h-[200px] rounded-lg w-[200px] mx-2 image-preview">
    <?php else: ?>
        <div class="detail-value">لا يوجد صورة</div>
    <?php endif; ?>
</div>

<div class="details-item">
                        <strong>الطاهي:</strong> <?php echo e($recipe->chef ? $recipe->chef->name : 'غير محدد'); ?>

                    </div>
                </div>

                <div class="details-item">
                    <strong>اسم المدخل:</strong> <?php echo e(Auth::user()->name); ?>

                </div>

                <div class="details-item">
                    <strong>نوع المطبخ:</strong>
                    <div class="" name="kitchen_type_id" id="kitchen_type_id" required>
                        <?php $__currentLoopData = $kitchens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kitchen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div value="<?php echo e($kitchen->id); ?>"
                                <?php echo e(old('kitchen_type_id', $recipe->kitchen_type_id) == $kitchen->id ? 'selected' : ''); ?>>
                                <?php echo e($kitchen->name_ar ?? $kitchen->name); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="details-item">
                    <strong>التصنيف الرئيسي:</strong> <?php echo e($recipe->mainCategories?->name_ar ?? 'غير محدد'); ?>

                </div>
                <div class="details-item">
                    <strong>التصنيفات الفرعية:</strong>
                    <div class="tags-container bg-green-500 rounded d-inline-block">
                        <?php $__empty_1 = true; $__currentLoopData = $recipe->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <span class="badge"><?php echo e($subCategory->name_ar); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <span class="text-muted">لا توجد</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="details-item">
                    <strong>تكفي ل:</strong> <?php echo e($recipe->servings); ?> أشخاص
                </div>
                <div class="details-item">
                    <strong>وقت التحضير:</strong> <?php echo e($recipe->preparation_time); ?> دقيقة
                </div>
                <div class="details-item">
                    <strong>السعرات الحرارية:</strong> <?php echo e($recipe->calories ?? 'غير محدد'); ?>

                </div>
                <div class="details-item">
                    <strong>الدهون:</strong> <?php echo e($recipe->fats ?? 'غير محدد'); ?> جرام
                </div>
                <div class="details-item">
                    <strong>الكربوهيدرات:</strong> <?php echo e($recipe->carbs ?? 'غير محدد'); ?> جرام
                </div>
                <div class="details-item">
                    <strong>البروتين:</strong> <?php echo e($recipe->protein ?? 'غير محدد'); ?> جرام
                </div>
                <div class="details-item">
                    <strong>نوع الوصفة:</strong>
                    <span class="status-badge <?php echo e($recipe->is_free ? 'status-free' : 'status-paid'); ?>">
                        <?php echo e($recipe->is_free ? 'مجانية' : 'مدفوعة'); ?>

                    </span>
                </div>
                <div class="details-item">
                    <strong>الحالة:</strong>
                    <span class="status-badge <?php echo e($recipe->status ? 'status-active' : 'status-inactive'); ?>">
                        <?php echo e($recipe->status ? 'فعال' : 'غير فعال'); ?>

                    </span>
                </div>
                <div class="details-item">
                    <strong>تاريخ الإنشاء:</strong> <?php echo e($recipe->created_at->format('d/m/Y H:i')); ?>

                </div>
                <div class="details-item">
                    <strong>آخر تحديث:</strong> <?php echo e($recipe->updated_at->format('d/m/Y H:i')); ?>

                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <h5 class="section-title">المكونات:</h5>
                <ul class="content-list">
                    <?php $__currentLoopData = explode("\n", $recipe->ingredients); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(trim($ingredient) !== ''): ?>
                            <li><i class="fas fa-check-circle"></i> <?php echo e(trim($ingredient)); ?></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>


            <div class="col-md-6">
                <h5 class="section-title">خطوات التحضير:</h5>
                <ol class="content-list">
                    <?php if($recipe->steps && is_array($recipe->steps) && count($recipe->steps) > 0): ?>
                        <?php $__currentLoopData = $recipe->steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <i class="fas fa-arrow-right"></i>
                                <?php echo e($step['description'] ?? 'بدون وصف'); ?>


                                <?php if(isset($step['media']) && is_array($step['media']) && !empty($step['media'])): ?>
                                    <div class="step-media mt-2">
                                        <?php $__currentLoopData = $step['media']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mediaItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                // *** التعديل الرئيسي هنا ***
                                                // تأكد من أننا نستخدم مفتاح 'url' لأنه هو الذي يجب أن يحتوي على المسار الكامل.
                                                // إذا لم يكن موجوداً، أو كان فارغاً، فسيعتبر المسار غير صالح.
                                                $mediaSource = $mediaItem['url'] ?? null;
                                                $mediaType = $mediaItem['type'] ?? 'unknown';
                                                $mediaName = $mediaItem['original_name'] ?? 'Media_' . $index;
                                            ?>

                                            
                                            <?php if($mediaSource && Storage::disk('public')->exists($mediaSource)): ?>
                                                <?php if(Str::startsWith($mediaType, 'image')): ?>
                                                    <img src="<?php echo e(Storage::url($mediaSource)); ?>" alt="<?php echo e($mediaName); ?>"
                                                        class="media-preview img-fluid">
                                                <?php elseif(Str::startsWith($mediaType, 'video')): ?>
                                                    <video controls class="media-preview video">
                                                        <source src="<?php echo e(Storage::url($mediaSource)); ?>"
                                                            type="<?php echo e($mediaType); ?>">
                                                        متصفحك لا يدعم تشغيل الفيديو.
                                                    </video>
                                                <?php else: ?>
                                                    <span class="text-warning">نوع ميديا غير مدعوم:
                                                        <?php echo e($mediaType); ?></span>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                
                                                <span class="text-danger">
                                                    الملف غير موجود أو المسار غير صالح:
                                                    <?php echo e($mediaSource ?: 'مسار غير محدد'); ?>

                                                </span>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <li class="text-warning">لا توجد خطوات متاحة</li>
                    <?php endif; ?>
                </ol>
            </div>
            



        </div>

        <div class="text-center mt-4">
            <a href="<?php echo e(route('admin.recipes.index')); ?>" class="btn btn-back">
                <i class="fas fa-arrow-right ms-1"></i>
                العودة لقائمة الوصفات
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\food-project\resources\views/admin/recipes/show.blade.php ENDPATH**/ ?>