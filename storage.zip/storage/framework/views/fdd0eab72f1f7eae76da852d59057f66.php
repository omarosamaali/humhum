<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Title -->
    <title>تواصل معنا</title>

    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="author" content="DexignZone">
    <meta name="robots" content="index, follow">

    <meta property="og:image" content="<?php echo e(asset('assets/images/social-image.png')); ?>">

    <meta name="format-detection" content="telephone=no">

    <meta name="twitter:title" content="Ombe- Coffee Shop Mobile App Template (Bootstrap + PWA) | DexignZone">
    <meta name="twitter:description" content="Discover the perfect blend of design and functionality with Ombe, a Coffee Shop Mobile App Template crafted with Bootstrap and enhanced with Progressive Web App (PWA) capabilities. Elevate your coffee shop's online presence with a seamless, responsive, and feature-rich template. Explore a modern design, user-friendly interface, and PWA technology for an immersive mobile experience. Brew success for your coffee shop effortlessly – Ombe is the ideal template to caffeinate your digital presence.">

    <meta name="twitter:image" content="<?php echo e(asset('assets/images/social-image.png')); ?>">
    <meta name="twitter:card" content="summary_large_image">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-LCY/8p2NaW6Bsmo1g3+6j+EkH0dY1o+2C73AVM0DIA3A92vN0bFz5H6uX3bM6+0F5a1g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Mobile Specific -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, minimal-ui, viewport-fit=cover">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Favicons Icon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/images/app-logo/favicon.png')); ?>">

    <!-- PWA Version -->
    <link rel="manifest" href="<?php echo e(asset('manifest.json')); ?>">

    <!-- Global CSS -->
    <link href="<?php echo e(asset('assets/vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/swiper/swiper-bundle.min.css')); ?>">

    <!-- Stylesheets -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800;900&family=Raleway:wght@300;400;500&display=swap" rel="stylesheet">
</head>

<body>
    <div class="page-wrapper">

        <!-- Preloader -->
        <div id="preloader">
            <div class="loader">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        </div>
        <!-- Preloader end-->

        <!-- Header -->
        <header class="header header-fixed">
            <div class="header-content">
                <div class="left-content">
                    <a href="javascript:void(0);" class="back-btn">
                        <i class="feather icon-arrow-left"></i>
                    </a>
                </div>
                <div class="mid-content">
                    <h4 class="title">المراسلات</h4>
                </div>
                <div>

                </div>
            </div>
        </header>
        <!-- Header -->

        <!-- Main Content Start -->
        <main class="page-content space-top" style="direction: rtl;">
            <div class="container">
                <div class="chat-list">
                    <ul id="myList" class="list-unstyled">
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('c1he3f.messages.show', $message->id)); ?>" class="list-items d-flex align-items-center p-3 border-bottom">
                                <div class="dz-media me-3">
                                    <?php if($message->status === 'unread'): ?>
                                    <i class="fa-regular fa-envelope" style="color: red; font-size: 60px;"></i>
                                    <?php elseif($message->status === 'opened'): ?>
                                    <i class="fa-regular fa-envelope-open" style="color: green; font-size: 60px;"></i>
                                    <?php elseif($message->status === 'replied'): ?>
                                    <i class="fa-regular fa-envelope-open" style="color: orange; font-size: 60px;"></i>
                                    <?php elseif($message->status === 'closed'): ?>
                                    <i class="fa-regular fa-envelope" style="color: blue; font-size: 60px;"></i>

                                    <?php endif; ?>
                                </div>
                                <div class="list-content">
                                    <h6 class="title"><?php echo e($message->title); ?></h6>
                                    <div class="dz-status">
                                        <span class="item-time">
                                            <?php echo e($message->created_at->diffForHumans()); ?>

                                            <i class="feather icon-clock me-1"></i>
                                        </span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </main>
        <!-- Main Content End -->
        <a href="<?php echo e(route('c1he3f.new-message')); ?>" style="position: fixed; bottom: 30px; left: 20px; z-index: 99999; ">
            <svg fill="#000" xmlns="http://www.w3.org/2000/svg" style="width: 25px;" viewBox="0 0 448 512">
                <path d="M64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32zM200 344l0-64-64 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l64 0 0-64c0-13.3 10.7-24 24-24s24 10.7 24 24l0 64 64 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-64 0 0 64c0 13.3-10.7 24-24 24s-24-10.7-24-24z">
                </path>
            </svg>
        </a>
    </div>

    <script src="<?php echo e(asset('assets/vendor/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dz.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/settings.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('index.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $("#myInput").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#myList li").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });

    </script>
</body>

</html>
<?php /**PATH F:\food-project\resources\views/c1he3f/messages.blade.php ENDPATH**/ ?>