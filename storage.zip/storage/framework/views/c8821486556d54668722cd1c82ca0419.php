

<?php $__env->startSection('title', 'إدارة الرسائل'); ?>
<?php $__env->startSection('page-title', 'إدارة الرسائل'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .add-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }

        .form-control,
        .form-select {
            border-radius: 8px;
            border: 1px solid #ddd;
            padding: 10px 15px;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }

        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
        }

        .action-buttons .btn {
            padding: 5px 10px;
            font-size: 12px;
            margin: 0 2px;
        }

        .badge-unread {
            background-color: #007bff;
        }

        .badge-opened {
            background-color: #28a745;
        }

        .badge-replied {
            background-color: #fd7e14;
        }

        .badge-closed {
            background-color: #dc3545;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- رسائل الفلاش -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- جدول عرض الرسائل -->
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>اسم المرسل</th>
                    <th>الصلاحية</th>
                    <th>تاريخ الإرسال</th>
                    <th>العنوان</th>
                    <th>المحتوى</th>
                    <th>الملف</th>
                    <th>الحالة</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($message->user->name ?? 'غير محدد'); ?></td>
                        <td><?php echo e($message->user->role ?? 'غير محدد'); ?></td>
                        <td><?php echo e($message->created_at->format('d/m/Y H:i')); ?></td>
                        <td><?php echo e($message->title); ?></td>
                        <td><?php echo e(Str::limit($message->content, 50)); ?></td>
                        <td>
                            <?php if($message->file_path): ?>
                                <?php if(pathinfo($message->file_path, PATHINFO_EXTENSION) === 'mp4'): ?>
                                    <video width="100%" controls>
                                        <source style="width: 60px; border-radius: 13px;"
                                            src="<?php echo e(asset('storage/' . $message->file_path)); ?>" type="video/mp4">
                                    </video>
                                <?php else: ?>
                                    <img style="width: 60px; border-radius: 13px;"
                                        src="<?php echo e(asset('storage/' . $message->file_path)); ?>" alt="">
                                <?php endif; ?>
                            <?php else: ?>
                                لا يوجد
                            <?php endif; ?>
                        </td>
                        <td>
                            <span
                                class="badge <?php echo e($message->status === 'unread' ? 'badge-unread' : ($message->status === 'opened' ? 'badge-opened' : ($message->status === 'closed' ? 'badge-closed' : 'badge-replied'))); ?>">
                                <?php echo e($message->status === 'unread' ? 'غير مقروءة' : ($message->status === 'opened' ? 'مفتوحة' : ($message->status === 'closed' ? 'مغلقة' : 'تم الرد'))); ?>

                            </span>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <a href="<?php echo e(route('admin.messages.show', $message->id)); ?>" class="btn btn-info btn-sm"
                                    title="عرض">
                                    <i class="fas fa-eye"></i>
                                </a>
                                
                                <button class="btn btn-danger btn-sm" title="حذف"
                                    onclick="confirmDelete(<?php echo e($message->id); ?>)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4">
                            <i class="fas fa-envelope text-muted" style="font-size: 3rem;"></i>
                            <p class="text-muted mt-2">لا توجد رسائل</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- روابط التصفح (Pagination) -->
    <?php if($messages->hasPages()): ?>
        <div class="flex justify-center mt-4">
            <?php echo e($messages->links('vendor.pagination.tailwind')); ?>

        </div>
    <?php endif; ?>

    <!-- Modal تأكيد الحذف -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تأكيد الحذف</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    هل أنت متأكد من حذف هذه الرسالة؟
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <form id="deleteForm" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btnDanger">حذف</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function confirmDelete(messageId) {
            const deleteForm = document.getElementById('deleteForm');
            deleteForm.action = `/admin/messages/${messageId}`;
            const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
            deleteModal.show();
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\food-project\resources\views/admin/messages/index.blade.php ENDPATH**/ ?>