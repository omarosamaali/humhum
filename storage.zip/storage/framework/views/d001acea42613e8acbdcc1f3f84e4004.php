

<?php $__env->startSection('title', 'إدارة الوصفات'); ?>
<?php $__env->startSection('page-title', 'قائمة الوصفات'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .header-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-section h5 {
            margin: 0;
            font-size: 1.5rem;
        }

        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
            margin-top: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .table thead {
            background-color: #667eea;
            color: white;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f8f9fa;
        }

        .table tbody tr:hover {
            background-color: #e9ecef;
        }

        .action-buttons {
            width: 123px;
        }

        .action-buttons .btn {
            padding: 5px 10px;
            font-size: 12px;
            margin: 0 2px;
            border-radius: 5px;
        }

        .recipe-img {
            width: 80px;
            height: 80px;
            border-radius: 8px;
            object-fit: cover;
            box-shadow: 0 0 3px rgba(0, 0, 0, 0.2);
        }

        .badge {
            padding: 0.5em 0.8em;
            border-radius: 5px;
            font-weight: normal;
        }

        .badge-success {
            background-color: #28a745;
            color: white;
        }

        .badge-danger {
            background-color: #dc3545;
            color: white;
        }

        .badge-info {
            background-color: #17a2b8;
            color: white;
        }

        .badge-warning {
            background-color: #ffc107;
            color: #333;
        }

        .badge-primary {
            background-color: #007bff;
            color: white;
        }

        .pagination .page-link {
            color: #667eea;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            margin: 0 2px;
        }

        .pagination .page-item.active .page-link {
            background-color: #667eea;
            border-color: #667eea;
            color: white;
        }

        .pagination .page-link:hover {
            background-color: #764ba2;
            color: white;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="header-section">
        <h5 class="mb-0">
            <i class="fas fa-utensils ms-2"></i>
            قائمة الوصفات
        </h5>
        <a href="<?php echo e(route('admin.recipes.create')); ?>" class="btn btn-light">
            <i class="fas fa-plus ms-1"></i>
            إضافة وصفة 
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>رقم الوصفة</th>
                    <th>صورة الطبق</th>
                    <th>عنوان الوصفة</th>
                    <th>نوع المطبخ</th>
                    <th>الشيف</th>
                    <th>التصنيف الرئيسي</th>
                    <th>التصنيفات الفرعية</th>
                    
                    
                    <th>الحالة</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration + ($recipes->currentPage() - 1) * $recipes->perPage()); ?></td>
                        <td><?php echo e($recipe->recipe_code); ?></td>
                        <td>
                            <?php if($recipe->dish_image): ?>
                                <img src="<?php echo e(Storage::url($recipe->dish_image)); ?>" alt="<?php echo e($recipe->title); ?>"
                                    class="recipe-img">
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/default-recipe-image.png')); ?>" alt="بدون صورة"
                                    class="recipe-img">
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($recipe->title); ?></td>

                        
                        <td>
                            
                            <?php echo e($recipe->kitchen ? $recipe->kitchen->name_ar : 'غير محدد'); ?>

                          
                        </td>
                        
                        <td><?php echo e($recipe->chef?->name ?? 'غير محدد'); ?></td>

                        
                        <td><?php echo e($recipe->mainCategories?->name_ar ?? 'غير محدد'); ?></td>

                        <td>
                            <?php $__empty_2 = true; $__currentLoopData = $recipe->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <span class="badge badge-info"><?php echo e($subCategory->name_ar); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <span class="text-muted">لا توجد</span>
                            <?php endif; ?>
                        </td>
                        
                        
                        <td>
                            <span class="badge <?php echo e($recipe->status ? 'badge-success' : 'badge-danger'); ?>">
                                <?php echo e($recipe->status ? 'فعال' : 'غير فعال'); ?>

                            </span>
                            <br class="mb-1">
                            <span class="badge <?php echo e($recipe->is_free ? 'badge-primary' : 'badge-warning'); ?>">
                                <?php echo e($recipe->is_free ? 'مجانية' : 'مدفوعة'); ?>

                            </span>
                        </td>
                        <td>
                            <div class="action-buttons">
                                <a href="<?php echo e(route('admin.recipes.show', $recipe->id)); ?>" class="btn btn-info btn-sm"
                                    title="عرض التفاصيل">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.recipes.edit', $recipe->id)); ?>" class="btn btn-warning btn-sm"
                                    title="تعديل">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button class="btn btn-danger btn-sm" title="حذف"
                                    onclick="confirmDelete(<?php echo e($recipe->id); ?>)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="11" class="text-center py-4">
                            <i class="fas fa-info-circle text-muted" style="font-size: 2rem;"></i>
                            <p class="text-muted mt-2">لا توجد وصفات حاليًا.</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <div class="d-flex justify-content-center mt-4">
        <?php echo e($recipes->links()); ?>

    </div>
   <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تأكيد الحذف</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    هل أنت متأكد من حذف هذه الوصفة؟
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <form id="deleteForm" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">حذف</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function confirmDelete(recipeId) {
            const deleteForm = document.getElementById('deleteForm');
            deleteForm.action = `/admin/recipes/${recipeId}`;
            const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
            deleteModal.show();
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\food-project\resources\views/admin/recipes/index.blade.php ENDPATH**/ ?>