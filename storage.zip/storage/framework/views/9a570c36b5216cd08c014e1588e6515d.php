

<?php $__env->startSection('content'); ?>
    <style>
        .details-card {
            background: white;
            color: black;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            position: relative;
        }

        .details-card h4 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 20px;
            border-bottom: 2px solid rgba(255, 255, 255, 0.3);
            padding-bottom: 10px;
        }

        .details-item {
            margin-bottom: 15px;
            font-size: 1.1rem;
            display: flex;
            /* justify-content: space-between; */
            flex-direction: row;
        }

        .details-item strong {
            margin-bottom: 5px;
            color: rgba(0, 0, 0, 0.8);
            font-weight: bold;
        }

        .details-image {
            width: 100%;
            height: 560px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        .status-badge {
            padding: 0.6em 1em;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: bold;
        }

        .status-active {
            background-color: #28a745;
            color: white;
        }

        .status-inactive {
            background-color: #dc3545;
            color: white;
        }

        .status-free {
            background-color: #17a2b8;
            color: white;
        }

        .status-paid {
            background-color: #ffc107;
            color: #333;
        }

        .btn-back {
            background-color: white;
            color: #764ba2;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .btn-back:hover {
            background-color: #eee;
            color: #667eea;
        }

        .section-title {
            font-size: 1.3rem;
            margin-top: 25px;
            margin-bottom: 10px;
            color: rgba(0, 0, 0, 0.9);
            border-bottom: 1px solid rgba(255, 255, 255, 0.5);
            padding-bottom: 5px;
        }

        .content-list {
            list-style: none;
            padding-left: 0;
        }

        .content-list li {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 8px 15px;
            border-radius: 5px;
            margin-bottom: 8px;
            display: flex;
            align-items: flex-start;
        }

        .content-list li i {
            margin-right: 10px;
            color: #a7d9ff;
            font-size: 1.2rem;
            margin-top: 3px;
        }

        .tags-container .badge {
            background-color: rgba(255, 255, 255, 0.2);
            color: black;
            margin-right: 5px;
            margin-bottom: 5px;
            padding: 0.6em 1em;
            border-radius: 5px;
            font-weight: normal;
        }

        .media-preview {
            max-width: 150px;
            max-height: 100px;
            object-fit: contain;
            border-radius: 5px;
            margin-left: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .media-preview.video {
            max-height: 120px;
        }
    </style>
    <div style="display: flex; gap: 20px;">

        <div class="recipe-image mb-4" style="width: 50%; min-width: 499px;">
            <?php if($recipe->dish_image): ?>
                <!-- Assuming 'image' is the field for the dish photo -->
                <img src="<?php echo e(Storage::url($recipe->dish_image)); ?>" alt="Recipe Image" class="details-image img-fluid rounded">
            <?php else: ?>
                <img src="<?php echo e(asset('assets/default-recipe.png')); ?>" alt="Default Recipe Image"
                    class="details-image img-fluid rounded">
            <?php endif; ?>
            <div class="col-md-12">

                <h5 class="section-title"
                    style="    color: #660099;
    font-size: 29px;
    border: 1px solid #660099;
    font-weight: bold;
    /* width: fit-content; */
    padding: 12px;
    border-radius: 12px;
    text-align: center;">
                    المكونات</h5>


                <?php
                    $sections = explode('##', $recipe->ingredients);
                    array_shift($sections);
                ?>

                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $lines = explode("\n", $section);
                        $title = trim(array_shift($lines));
                    ?>

                    <?php if($title !== ''): ?>
                        <div
                            style="margin-bottom: 5px; justify-content: space-between; font-weight: bold; border-bottom: 1px solid #ccc; padding-bottom: 2px; display: flex; align-items: center; gap: 5px;">
                            <?php echo e($title); ?>

                            <h1
                                style="color: #ffffff; font-size: 29px; background: #660099; font-weight: bold; padding: 5px; border-radius: 12px; text-align: center;">
                                <i style="font-size: 20px; color: #ffffff;" class="fa-solid fa-headphones"></i>
                            </h1>
                        </div>

                        <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $trimmed = trim($ingredient); ?>
                            <?php if($trimmed !== ''): ?>
                                <div
                                    style="margin-bottom: 5px; justify-content: space-between; display: flex; align-items: center; gap: 5px;">
                                    <?php echo e($trimmed); ?>

                                    <h1
                                        style="color: #ffffff; font-size: 29px; background: #660099; font-weight: bold; padding: 5px; border-radius: 12px; text-align: center;">
                                        <i style="font-size: 20px; color: #ffffff;" class="fa-solid fa-headphones"></i>
                                    </h1>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>

        <div>

            <div class="recipe-number mb-3">
                <span class="badge bg-primary fs-6">#<?php echo e($recipe->recipe_code); ?></span>
            </div>
            <div style="display: flex; gap; 20px; ">

                <h1
                    style="    color: #660099;
    font-size: 29px;
    border: 1px solid #660099;
    font-weight: bold;
    padding: 12px;
    border-radius: 12px;
    text-align: center; margin-left: 20px;">
                    <?php echo e($recipe->title); ?>

                </h1>
                <h1
                    style="    color: #ffffff;
    font-size: 29px;
    background:  #660099;
    font-weight: bold;
    padding: 12px;
    border-radius: 12px;
    text-align: center;">
                    <i style="color: #ffffff;" class="fa-solid fa-headphones"></i>
                </h1>

            </div>
            <div style="display: flex; align-items: center; justify-content: space-between;">
                <div>
                    
                    <img src="<?php echo e($currentLanguage->flag_image ? Storage::url($currentLanguage->flag_image) : asset('assets/default-flag.png')); ?>"
                        alt="<?php echo e($currentLanguage->name); ?>" class="flag-img rounded"
                        style="width: 40px; height: 40px; margin-left: 8px; object-fit: cover;">
                    <?php echo e($currentLanguage->name); ?>

                </div>
                <div>
                    <?php if($recipe->chef): ?>
                        <?php
                            $chefDisplayName = 'Not Translated';
                            if ($recipe->chef) {
                                $chefFieldName = 'name_' . $currentLanguageCode;
                                $chefDisplayName =
                                    $recipe->chef->{$chefFieldName} ??
                                    ($recipe->chef->name_ar ?? ($recipe->chef->name ?? 'Not Translated'));
                            }
                        ?>
                        <div class="detail-item" style="margin-top: 20px;">
                            <?php if($recipe->chef->chefProfile && $recipe->chef->chefProfile->official_image): ?>
                                <img src="<?php echo e(Storage::url($recipe->chef->chefProfile->official_image)); ?>"
                                    alt="<?php echo e($chefDisplayName); ?>" class="chef-img rounded-circle me-2"
                                    style="width: 40px; height: 40px;">
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/default-chef.png')); ?>" alt="Default Chef"
                                    class="chef-img rounded-circle me-2" style="width: 40px; height: 40px;">
                            <?php endif; ?>
                            الطاهي :
                            <?php echo e($chefDisplayName); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <div>
                    <?php if($recipe->kitchen): ?>
                        <?php
                            $kitchenName =
                                $recipe->kitchen->{'name_' . $currentLanguageCode} ??
                                ($recipe->kitchen->name_ar ?? 'Not Translated');
                        ?>
                        <div class="detail-item">
                            <?php if($recipe->kitchen->image): ?>
                                <img src="<?php echo e(Storage::url($recipe->kitchen->image)); ?>" alt="<?php echo e($kitchenName); ?>"
                                    class="kitchen-img rounded-circle me-2" style="width: 40px; height: 40px;">
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/default-kitchen.png')); ?>" alt="صورة مطبخ افتراضي"
                                    class="kitchen-img rounded-circle me-2" style="width: 40px; height: 40px;">
                            <?php endif; ?>
                            <?php echo e($kitchenName); ?>


                        </div>
                    <?php endif; ?>
                </div>

            </div>

            <div style="display: flex; align-items: center; gap: 20px;">

                <?php if($recipe->mainCategories): ?>
                    <?php
                        $mainCategoryName =
                            $recipe->mainCategories->{'name_' . $currentLanguageCode} ??
                            ($recipe->mainCategories->name_ar ?? 'Not Translated');
                    ?>
                    <div class="detail-item" style="">
                        <?php if($recipe->mainCategories->image): ?>
                            <img src="<?php echo e(url($recipe->mainCategories->image)); ?>" alt="here"
                                class="main-category-img rounded-circle me-2" style="width: 40px; height: 40px;">
                        <?php else: ?>
                            <img src="<?php echo e(asset('assets/default-category.png')); ?>" alt="صورة تصنيف افتراضي"
                                class="main-category-img rounded-circle me-2" style="width: 40px; height: 40px;">
                        <?php endif; ?>
                        <?php echo e($mainCategoryName); ?>

                    </div>
                <?php endif; ?>

                <?php if($recipe->subCategories->count()): ?>
                    <div class="detail-item">
                        <?php $__currentLoopData = $recipe->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $subCategoryName =
                                    $subCategory->{'name_' . $currentLanguageCode} ??
                                    ($subCategory->name_ar ?? 'Not Translated');
                            ?>
                            <span class="badge bg-info me-1"><?php echo e($subCategoryName); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <?php if($recipe->preparation_time): ?>
                    <div class="detail-item"><i class="fas fa-clock" style="color: #007bff;"></i>
                        <?php switch($currentLanguageCode):
                            case ('ar'): ?>
                                وقت التحضير
                            <?php break; ?>

                            <?php case ('en'): ?>
                                Preparation Time
                            <?php break; ?>

                            <?php case ('id'): ?>
                                Waktu Persiapan
                            <?php break; ?>

                            <?php case ('am'): ?>
                                የማዘመን ጊዜ
                            <?php break; ?>

                            <?php case ('hi'): ?>
                                तैयारी का समय
                            <?php break; ?>

                            <?php case ('bn'): ?>
                                প্রস্তুতি সময়
                            <?php break; ?>

                            <?php case ('ml'): ?>
                                തയ്യാറാക്കുന്ന സമയം
                            <?php break; ?>

                            <?php case ('fil'): ?>
                                Oras ng Paghanda
                            <?php break; ?>

                            <?php case ('ur'): ?>
                                تیاری کا وقت
                            <?php break; ?>

                            <?php case ('ta'): ?>
                                தயாரிப்பு நேரம்
                            <?php break; ?>

                            <?php case ('ne'): ?>
                                तयारी समय
                            <?php break; ?>

                            <?php default: ?>
                                Preparation Time
                        <?php endswitch; ?>:
                        <?php echo e($recipe->preparation_time); ?>

                        <?php switch($currentLanguageCode):
                            case ('ar'): ?>
                                دقيقة
                            <?php break; ?>

                            <?php case ('en'): ?>
                                minutes
                            <?php break; ?>

                            <?php case ('id'): ?>
                                menit
                            <?php break; ?>

                            <?php case ('am'): ?>
                                ሒውሎች
                            <?php break; ?>

                            <?php case ('hi'): ?>
                                मिनट
                            <?php break; ?>

                            <?php case ('bn'): ?>
                                মিনিট
                            <?php break; ?>

                            <?php case ('ml'): ?>
                                മിനിറ്റുകൾ
                            <?php break; ?>

                            <?php case ('fil'): ?>
                                minuto
                            <?php break; ?>

                            <?php case ('ur'): ?>
                                منٹ
                            <?php break; ?>

                            <?php case ('ta'): ?>
                                நிமிடங்கள்
                            <?php break; ?>

                            <?php case ('ne'): ?>
                                मिनेट
                            <?php break; ?>

                            <?php default: ?>
                                minutes
                        <?php endswitch; ?>
                    </div>
                <?php endif; ?>


            </div>

            <div class="recipe-details mb-4">
                <div class="row">
                    <div class="col-md-12 text-right">
                        <div style="display: flex; gap: 10px;">
                            <?php if($recipe->protein): ?>
                                <div class="detail-item" style="color: #0c1e24;">
                                    <span
                                        style="background-color: #e4ebf1;
                                        border-radius: 5px;
                                        width: 39px;
                                        height: 40px;
                                        display: inline-flex;
                                        align-items: center;
                                        justify-content: center;
                                        margin-left: 5px;">
                                        <i class="fas fa-egg" style="color: #0c1e24;"></i>
                                    </span>
                                    <span>
                                        <?php echo e($recipe->protein); ?>

                                    </span>
                                    <?php switch($currentLanguageCode):
                                        case ('ar'): ?>
                                            بروتين
                                        <?php break; ?>

                                        <?php case ('en'): ?>
                                            calories
                                        <?php break; ?>

                                        <?php case ('id'): ?>
                                            kalori
                                        <?php break; ?>

                                        <?php case ('am'): ?>
                                            ካሎሪ
                                        <?php break; ?>

                                        <?php case ('hi'): ?>
                                            कैलोरी
                                        <?php break; ?>

                                        <?php case ('bn'): ?>
                                            ক্যালোরি
                                        <?php break; ?>

                                        <?php case ('ml'): ?>
                                            കലോറി
                                        <?php break; ?>

                                        <?php case ('fil'): ?>
                                            kalorya
                                        <?php break; ?>

                                        <?php case ('ur'): ?>
                                            کیلوری
                                        <?php break; ?>

                                        <?php case ('ta'): ?>
                                            கலோரி
                                        <?php break; ?>

                                        <?php case ('ne'): ?>
                                            क्यालोरी
                                        <?php break; ?>

                                        <?php default: ?>
                                            calories
                                    <?php endswitch; ?>
                                </div>
                            <?php endif; ?>
                            <?php if($recipe->calories): ?>
                                <div class="detail-item" style="color: #0c1e24;">
                                    <span
                                        style="background-color: #e4ebf1;
                                        border-radius: 5px;
                                        width: 39px;
                                        height: 40px;
                                        display: inline-flex;
                                        align-items: center;
                                        justify-content: center;
                                        margin-left: 5px;">
                                        <i class="fas fa-fire" style="color: #0c1e24;"></i>
                                    </span>
                                    <span>
                                        <?php echo e($recipe->calories); ?>

                                    </span>
                                    <?php switch($currentLanguageCode):
                                        case ('ar'): ?>
                                            سعرة
                                        <?php break; ?>

                                        <?php case ('en'): ?>
                                            calories
                                        <?php break; ?>

                                        <?php case ('id'): ?>
                                            kalori
                                        <?php break; ?>

                                        <?php case ('am'): ?>
                                            ካሎሪ
                                        <?php break; ?>

                                        <?php case ('hi'): ?>
                                            कैलोरी
                                        <?php break; ?>

                                        <?php case ('bn'): ?>
                                            ক্যালোরি
                                        <?php break; ?>

                                        <?php case ('ml'): ?>
                                            കലോറി
                                        <?php break; ?>

                                        <?php case ('fil'): ?>
                                            kalorya
                                        <?php break; ?>

                                        <?php case ('ur'): ?>
                                            کیلوری
                                        <?php break; ?>

                                        <?php case ('ta'): ?>
                                            கலோரி
                                        <?php break; ?>

                                        <?php case ('ne'): ?>
                                            क्यालोरी
                                        <?php break; ?>

                                        <?php default: ?>
                                            calories
                                    <?php endswitch; ?>
                                </div>
                            <?php endif; ?>
                            <?php if($recipe->fats): ?>
                                <div class="detail-item" style="color: #0c1e24;">
                                    <span
                                        style="background-color: #e4ebf1;
                                        border-radius: 5px;
                                        width: 39px;
                                        height: 40px;
                                        display: inline-flex;
                                        align-items: center;
                                        justify-content: center;
                                        margin-left: 5px;">
                                        <i class="fas fa-tint" style="color: #0c1e24;"></i>
                                    </span>
                                    <?php echo e($recipe->fats); ?>

                                    <?php switch($currentLanguageCode):
                                        case ('ar'): ?>
                                            غرام
                                        <?php break; ?>

                                        <?php case ('en'): ?>
                                            grams
                                        <?php break; ?>

                                        <?php case ('id'): ?>
                                            gram
                                        <?php break; ?>

                                        <?php case ('am'): ?>
                                            ግራም
                                        <?php break; ?>

                                        <?php case ('hi'): ?>
                                            ग्राम
                                        <?php break; ?>

                                        <?php case ('bn'): ?>
                                            গ্রাম
                                        <?php break; ?>

                                        <?php case ('ml'): ?>
                                            ഗ്രാം
                                        <?php break; ?>

                                        <?php case ('fil'): ?>
                                            gramo
                                        <?php break; ?>

                                        <?php case ('ur'): ?>
                                            گرام
                                        <?php break; ?>

                                        <?php case ('ta'): ?>
                                            கிராம்
                                        <?php break; ?>

                                        <?php case ('ne'): ?>
                                            ग्राम
                                        <?php break; ?>

                                        <?php default: ?>
                                            grams
                                    <?php endswitch; ?>
                                </div>
                            <?php endif; ?>
                            <?php if($recipe->carbs): ?>
                                <div class="detail-item" style="color: #0c1e24;">
                                    <span
                                        style="background-color: #e4ebf1;
                                        border-radius: 5px;
                                        width: 39px;
                                        height: 40px;
                                        display: inline-flex;
                                        align-items: center;
                                        justify-content: center;
                                        margin-left: 5px;">
                                        <i class="fa-brands fa-pagelines" style="color: #0c1e24;"></i>
                                    </span>
                                    <?php echo e($recipe->carbs); ?>

                                    <?php switch($currentLanguageCode):
                                        case ('ar'): ?>
                                            الكربوهيدرات
                                        <?php break; ?>

                                        <?php case ('en'): ?>
                                            grams
                                        <?php break; ?>

                                        <?php case ('id'): ?>
                                            gram
                                        <?php break; ?>

                                        <?php case ('am'): ?>
                                            ግራም
                                        <?php break; ?>

                                        <?php case ('hi'): ?>
                                            ग्राम
                                        <?php break; ?>

                                        <?php case ('bn'): ?>
                                            গ্রাম
                                        <?php break; ?>

                                        <?php case ('ml'): ?>
                                            ഗ്രാം
                                        <?php break; ?>

                                        <?php case ('fil'): ?>
                                            gramo
                                        <?php break; ?>

                                        <?php case ('ur'): ?>
                                            گرام
                                        <?php break; ?>

                                        <?php case ('ta'): ?>
                                            கிராம்
                                        <?php break; ?>

                                        <?php case ('ne'): ?>
                                            ग्राम
                                        <?php break; ?>

                                        <?php default: ?>
                                            grams
                                    <?php endswitch; ?>
                                </div>
                            <?php endif; ?>
                            <?php if($recipe->servings): ?>
                                <div class="detail-item" style="color: #0c1e24; display: flex; align-items: center;">
                                    <span
                                        style="background-color: #e4ebf1;
                                    border-radius: 5px;
                                    width: 39px;
                                    height: 40px;
                                    display: inline-flex;
                                    align-items: center;
                                    justify-content: center;
                                    margin-left: 5px;">
                                        <i class="fas fa-user" style="color: #0c1e24;"></i>
                                    </span>
                                    <?php echo e($recipe->servings); ?>

                                    <?php switch($currentLanguageCode):
                                        case ('ar'): ?>
                                            شخص
                                        <?php break; ?>

                                        <?php case ('en'): ?>
                                            people
                                        <?php break; ?>

                                        <?php case ('id'): ?>
                                            orang
                                        <?php break; ?>

                                        <?php case ('am'): ?>
                                            ሰዎች
                                        <?php break; ?>

                                        <?php case ('hi'): ?>
                                            लोग
                                        <?php break; ?>

                                        <?php case ('bn'): ?>
                                            মানুষ
                                        <?php break; ?>

                                        <?php case ('ml'): ?>
                                            ആളുകൾ
                                        <?php break; ?>

                                        <?php case ('fil'): ?>
                                            katao
                                        <?php break; ?>

                                        <?php case ('ur'): ?>
                                            افراد
                                        <?php break; ?>

                                        <?php case ('ta'): ?>
                                            நபர்கள்
                                        <?php break; ?>

                                        <?php case ('ne'): ?>
                                            मानिसहरु
                                        <?php break; ?>

                                        <?php default: ?>
                                            servings
                                    <?php endswitch; ?>
                                </div>
                            <?php endif; ?>
                        </div>


                    </div>
                    <div class="detail-item" style="display: flex; justify-content: space-between;">
                        <?php if($recipe->user): ?>
                            <div class="detail-item" style="font-weight: bold;"><i class="fas fa-user"
                                    style="color: #28a745;"></i>
                                <?php switch($currentLanguageCode):
                                    case ('ar'): ?>
                                        الناشر
                                    <?php break; ?>

                                    <?php case ('en'): ?>
                                        The recipe was entered by
                                    <?php break; ?>

                                    <?php case ('id'): ?>
                                        Resep dimasukkan oleh
                                    <?php break; ?>

                                    <?php case ('am'): ?>
                                        የምግብ አሰራር በ
                                    <?php break; ?>

                                    <?php case ('hi'): ?>
                                        रेसिपी दर्ज की गई
                                    <?php break; ?>

                                    <?php case ('bn'): ?>
                                        রেসিপি প্রবেশ করিয়েছে
                                    <?php break; ?>

                                    <?php case ('ml'): ?>
                                        പാചകക്കുറിപ്പ് നൽകിയത്
                                    <?php break; ?>

                                    <?php case ('fil'): ?>
                                        Ang recipe ay inilagay ni
                                    <?php break; ?>

                                    <?php case ('ur'): ?>
                                        ترکیب درج کی گئی ہے
                                    <?php break; ?>

                                    <?php case ('ta'): ?>
                                        செய்முறை உள்ளிடப்பட்டது
                                    <?php break; ?>

                                    <?php case ('ne'): ?>
                                        रेसिपी द्वारा प्रविष्ट गरियो
                                    <?php break; ?>

                                    <?php default: ?>
                                        The recipe was entered by
                                <?php endswitch; ?>: <?php echo e($recipe->user->name ?? ($recipe->user_id ?? 'Not Assigned')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="detail-item"><i class="fas fa-calendar" style="color: #6c757d;"></i>
                            <?php switch($currentLanguageCode):
                                case ('ar'): ?>
                                    تاريخ النشر
                                <?php break; ?>

                                <?php case ('en'): ?>
                                    Publish Date
                                <?php break; ?>

                                <?php case ('id'): ?>
                                    Tanggal Publikasi
                                <?php break; ?>

                                <?php case ('am'): ?>
                                    የነፃ ቀን
                                <?php break; ?>

                                <?php case ('hi'): ?>
                                    प्रकाशन तिथि
                                <?php break; ?>

                                <?php case ('bn'): ?>
                                    প্রকাশের তারিখ
                                <?php break; ?>

                                <?php case ('ml'): ?>
                                    പ്രകാശന തീയതി
                                <?php break; ?>

                                <?php case ('fil'): ?>
                                    Petsa ng Paglalathala
                                <?php break; ?>

                                <?php case ('ur'): ?>
                                    شائع کرنے کی تاریخ
                                <?php break; ?>

                                <?php case ('ta'): ?>
                                    வெளியிடப்பட்ட தேதி
                                <?php break; ?>

                                <?php case ('ne'): ?>
                                    प्रकाशन मिति
                                <?php break; ?>

                                <?php default: ?>
                                    Publish Date
                            <?php endswitch; ?>:
                            <?php echo e($recipe->created_at->format('Y-m-d')); ?>

                        </div>
                        <?php if($recipe->updated_at): ?>
                            <div class="detail-item"><i class="fas fa-calendar-check" style="color: #28a745;"></i>
                                <?php switch($currentLanguageCode):
                                    case ('ar'): ?>
                                        تاريخ التحديث
                                    <?php break; ?>

                                    <?php case ('en'): ?>
                                        Update Date
                                    <?php break; ?>

                                    <?php case ('id'): ?>
                                        Tanggal Perbarui
                                    <?php break; ?>

                                    <?php case ('am'): ?>
                                        የመረጋገጫ ቀን
                                    <?php break; ?>

                                    <?php case ('hi'): ?>
                                        अद्यतन तिथि
                                    <?php break; ?>

                                    <?php case ('bn'): ?>
                                        হালনাগাদের তারিখ
                                    <?php break; ?>

                                    <?php case ('ml'): ?>
                                        അപ്ഡേറ്റ് തീയതി
                                    <?php break; ?>

                                    <?php case ('fil'): ?>
                                        Petsa ng Pag-update
                                    <?php break; ?>

                                    <?php case ('ur'): ?>
                                        اپ ڈیٹ کی تاریخ
                                    <?php break; ?>

                                    <?php case ('ta'): ?>
                                        புதுப்பிப்பு தேதி
                                    <?php break; ?>

                                    <?php case ('ne'): ?>
                                        अपडेट मिति
                                    <?php break; ?>

                                    <?php default: ?>
                                        Update Date
                                <?php endswitch; ?>:
                                <?php echo e($recipe->updated_at->format('Y-m-d')); ?>

                            </div>
                        <?php endif; ?>

                    </div>

                    <?php if($recipe->recipeSteps->count()): ?>
                        <div class="card mb-4">
                            <div class="card-header bg-primary text-white">Preparation Steps</div>
                            <div class="card-body">
                                <?php $__currentLoopData = $recipe->recipeSteps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e($step->translations->where('language_code', $currentLanguageCode)->first()->description ?? 'Not Translated'); ?>

                                    </p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="">
                        <h5 class="section-title"
                            style="    color: #660099;
    font-size: 29px;
    border: 1px solid #660099;
    font-weight: bold;
    /* width: fit-content; */
    padding: 12px;
    border-radius: 12px;
    text-align: center;">
                            خطوات التحضير</h5>
                        <ol class="content-list">
                            <?php if($recipe->steps && is_array($recipe->steps) && count($recipe->steps) > 0): ?>
                                <?php $__currentLoopData = $recipe->steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li style="flex-direction: column;">
                                        <span
                                            style="background: #660099;
    color: white;
    font-weight: bold;
    width: 28px;
    height: 28px;
    text-align: center;
    align-items: center;
    justify-content: center;
    display: flex;
    border-radius: 50px;">
                                            <?php echo e($index + 1); ?>

                                        </span>
                                        
<?php $__currentLoopData = $recipe->steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div style="display: flex; align-items: flex-start; margin-bottom: 15px;">

    <div style="flex-grow: 1; padding-right: 15px;">
        
        <?php echo e($step['description'] ?? 'بدون وصف'); ?>


        
        <?php if(isset($step['media_path']) && !empty($step['media_path'])): ?>
        <?php
        $stepMediaType = $step['media_type'] ?? null; // Get media type, default to null
        // Construct the full URL for the media using Storage::url()
        // Assuming $step['media_path'] is something like 'recipes/steps/image.jpg'
        $stepMediaSrc = url($step['media_path']);
        ?>

        <div class="step-media-container" style="margin-top: 10px;">
            <?php if($stepMediaType === 'image'): ?>
            <img src="<?php echo e($stepMediaSrc); ?>" alt="صورة الخطوة" style="max-width: 200px; max-height: 150px; object-fit: contain; border-radius: 5px; display: block; margin-top: 5px;">
            <?php elseif($stepMediaType === 'video'): ?>
            <video src="<?php echo e($stepMediaSrc); ?>" controls style="max-width: 250px; max-height: 180px; border-radius: 5px; display: block; margin-top: 5px;"></video>
            <?php else: ?>
            
            <p style="color: red;">نوع الوسائط غير مدعوم أو غير محدد.</p>
            <a href="<?php echo e($stepMediaSrc); ?>" target="_blank">عرض الملف</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        
        <?php if(isset($step['media']) && !empty($step['media'])): ?>
        <div class="multiple-media-previews" style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px;">
            <?php $__currentLoopData = $step['media']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="media-item" style="position: relative;">
                <?php if(str_contains($media['type'], 'image')): ?>
                <img src="<?php echo e(asset($media['url'])); ?>" style="width: 150px; max-height: 100px; border-radius: 5px;">
                <?php else: ?>
                <video src="<?php echo e(asset($media['url'])); ?>" controls style="width: 150px; max-height: 100px; border-radius: 5px;"></video>
                <?php endif; ?>
                <button class="btn btn-sm btn-danger remove-single-media" style="position: absolute; top: -8px; right: -8px; border-radius: 50%; width: 24px; height: 24px; padding: 0;">×</button>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>

    
    <span style="margin-right: 10px; color: #ffffff; font-size: 29px; text-align: center; background: #660099; font-weight: bold; padding: 12px; border-radius: 12px; display: flex; align-items: center; justify-content: center; min-width: 50px; height: 50px;">
        <i style="margin: 0px; color: #ffffff;" class="fa-solid fa-headphones"></i>
    </span>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <div class="multiple-media-previews"

                                            style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px;">
                                            <?php if(!empty($step['media'])): ?>
                                                <?php $__currentLoopData = $step['media']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="media-item">
                                                        <?php if(str_contains($media['type'], 'image')): ?>
                                                            <img src="<?php echo e(asset('' . $media['url'])); ?>"
                                                                style="width: 150px; max-height: 100px; border-radius: 5px;">
                                                        <?php else: ?>
                                                            <video src="<?php echo e(asset('' . $media['url'])); ?>" controls
                                                                style="width: 150px; max-height: 100px; border-radius: 5px;"></video>
                                                        <?php endif; ?>
                                                        <button class="btn btn-sm btn-danger remove-single-media"
                                                            style="position: absolute; top: -8px; right: -8px; border-radius: 50%; width: 24px; height: 24px; padding: 0;">×</button>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <li class="text-warning">لا توجد خطوات متاحة</li>
                            <?php endif; ?>
                        </ol>
                    </div>

                    <div class="mt-4"
                        style="    position: fixed;
    width: fit-content;
    bottom: 14px;
    right: 12px;
    z-index: 999999999999999999;">
                        <button type="button" onclick="backOnePage();" class="btn btn-secondary"
                            style="background: #660099; border: #660099;">الرجوع</button>
                    </div>

                </div>
            </div>

        <?php $__env->stopSection(); ?>

        <?php $__env->startPush('styles'); ?>
            <style>
                .detail-item {
                    padding-bottom: 0.5rem;
                }

                .detail-item:last-child {
                    border-bottom: none;
                }
            </style>
        <?php $__env->stopPush(); ?>
        <script>
            function backOnePage() {
                window.history.back();
            }
        </script>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\food-project\resources\views/admin/recipes/preview.blade.php ENDPATH**/ ?>